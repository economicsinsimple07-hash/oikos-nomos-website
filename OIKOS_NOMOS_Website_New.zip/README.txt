OIKOS & NOMOS WEBSITE

Files:
- index.html
- style.css

How to use:
1. Open index.html in any browser.
2. Upload both files to your web hosting.
3. The Student Login is currently a visual front-end only; connect Firebase/Auth before using it for real accounts.
